#include <stdio.h>
#include <string.h>
#include "login.h"

#define USERNAME "admin"
#define PASSWORD "admin123"
#define MAX_ATTEMPTS 3

int login(void)
{
    char username[50];
    char password[50];
    int attempts = 0;

    printf("\n========================================\n");
    printf("       MUNICIPAL FINANCIAL SYSTEM\n");
    printf("              LOGIN\n");
    printf("========================================\n");

    while (attempts < MAX_ATTEMPTS)
    {
        printf("\nUsername: ");
        scanf("%49s", username);

        printf("Password: ");
        scanf("%49s", password);

        if (strcmp(username, USERNAME) == 0 &&
            strcmp(password, PASSWORD) == 0)
        {
            printf("\nLogin successful.\n");
            printf("Welcome to the Municipal Financial Management System.\n");
            return 1;
        }

        attempts++;

        printf("\nInvalid username or password.\n");

        if (attempts < MAX_ATTEMPTS)
        {
            printf("Attempts remaining: %d\n",
                   MAX_ATTEMPTS - attempts);
        }
    }

    printf("\nMaximum login attempts reached.\n");
    printf("Access denied.\n");

    return 0;
}
#include <stdio.h>
#include <string.h>
#include "assets.h"

#define MAX_ASSETS 100

typedef struct
{
    int assetID;
    char assetName[100];
    char assetType[50];
    double purchaseValue;
    char department[100];
    char condition[50];
} Asset;

static Asset assets[MAX_ASSETS];
static int assetCount = 0;

static void clearInputBuffer(void)
{
    int c;

    while ((c = getchar()) != '\n' && c != EOF)
    {
    }
}

static void removeNewline(char text[])
{
    text[strcspn(text, "\n")] = '\0';
}

void assetMenu(void)
{
    int choice = 0;

    do
    {
        printf("\n========================================\n");
        printf("            ASSET MANAGEMENT\n");
        printf("========================================\n");
        printf("1. Add Asset\n");
        printf("2. Display Assets\n");
        printf("3. Search Asset\n");
        printf("4. Return to Main Menu\n");
        printf("Enter your choice: ");

        if (scanf("%d", &choice) != 1)
        {
            printf("\nInvalid input. Please enter a number.\n");
            clearInputBuffer();
            choice = 0;
            continue;
        }

        clearInputBuffer();

        switch (choice)
        {
            case 1:
                addAsset();
                break;

            case 2:
                displayAssets();
                break;

            case 3:
                searchAsset();
                break;

            case 4:
                printf("\nReturning to Main Menu...\n");
                break;

            default:
                printf("\nInvalid choice. Please enter 1 to 4.\n");
        }

    } while (choice != 4);
}

void addAsset(void)
{
    int i;

    if (assetCount >= MAX_ASSETS)
    {
        printf("\nAsset storage is full.\n");
        return;
    }

    printf("\n--- ADD ASSET ---\n");

    printf("Enter Asset ID: ");

    if (scanf("%d", &assets[assetCount].assetID) != 1)
    {
        printf("Invalid Asset ID.\n");
        clearInputBuffer();
        return;
    }

    clearInputBuffer();

    /* Check for duplicate asset ID */
    for (i = 0; i < assetCount; i++)
    {
        if (assets[i].assetID == assets[assetCount].assetID)
        {
            printf("An asset with this ID already exists.\n");
            return;
        }
    }

    printf("Enter Asset Name: ");
    fgets(assets[assetCount].assetName,
          sizeof(assets[assetCount].assetName), stdin);
    removeNewline(assets[assetCount].assetName);

    if (strlen(assets[assetCount].assetName) == 0)
    {
        printf("Asset name cannot be empty.\n");
        return;
    }

    printf("Enter Asset Type: ");
    fgets(assets[assetCount].assetType,
          sizeof(assets[assetCount].assetType), stdin);
    removeNewline(assets[assetCount].assetType);

    printf("Enter Purchase Value: N$");

    if (scanf("%lf", &assets[assetCount].purchaseValue) != 1)
    {
        printf("Invalid purchase value.\n");
        clearInputBuffer();
        return;
    }

    clearInputBuffer();

    if (assets[assetCount].purchaseValue < 0)
    {
        printf("Purchase value cannot be negative.\n");
        return;
    }

    printf("Enter Department: ");
    fgets(assets[assetCount].department,
          sizeof(assets[assetCount].department), stdin);
    removeNewline(assets[assetCount].department);

    printf("Enter Condition: ");
    fgets(assets[assetCount].condition,
          sizeof(assets[assetCount].condition), stdin);
    removeNewline(assets[assetCount].condition);

    assetCount++;

    printf("\nAsset added successfully.\n");
}

void displayAssets(void)
{
    int i;

    if (assetCount == 0)
    {
        printf("\nNo assets have been registered yet.\n");
        return;
    }

    printf("\n========================================\n");
    printf("              ASSET REGISTER\n");
    printf("========================================\n");

    for (i = 0; i < assetCount; i++)
    {
        printf("\nAsset %d\n", i + 1);
        printf("----------------------------------------\n");
        printf("Asset ID:       %d\n", assets[i].assetID);
        printf("Asset Name:     %s\n", assets[i].assetName);
        printf("Asset Type:     %s\n", assets[i].assetType);
        printf("Purchase Value: N$%.2f\n",
               assets[i].purchaseValue);
        printf("Department:     %s\n", assets[i].department);
        printf("Condition:      %s\n", assets[i].condition);
    }
}

void searchAsset(void)
{
    int searchID;
    int i;

    if (assetCount == 0)
    {
        printf("\nNo assets have been registered yet.\n");
        return;
    }

    printf("\nEnter Asset ID to search: ");

    if (scanf("%d", &searchID) != 1)
    {
        printf("Invalid Asset ID.\n");
        clearInputBuffer();
        return;
    }

    clearInputBuffer();

    for (i = 0; i < assetCount; i++)
    {
        if (assets[i].assetID == searchID)
        {
            printf("\n--- ASSET FOUND ---\n");
            printf("Asset ID:       %d\n", assets[i].assetID);
            printf("Asset Name:     %s\n", assets[i].assetName);
            printf("Asset Type:     %s\n", assets[i].assetType);
            printf("Purchase Value: N$%.2f\n",
                   assets[i].purchaseValue);
            printf("Department:     %s\n", assets[i].department);
            printf("Condition:      %s\n", assets[i].condition);
            return;
        }
    }

    printf("\nAsset with ID %d was not found.\n", searchID);
}